#pragma once
#include "Product.h"

class Decorator : public Product
{
public:
	Decorator(void);
	Decorator(Product* p) { P = p;};
	~Decorator(void);

	int getPrice() {return 0;};
	string getDescription() {return NULL; };

protected:
	Product* P;
};

