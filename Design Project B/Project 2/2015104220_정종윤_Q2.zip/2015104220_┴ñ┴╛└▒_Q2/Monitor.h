#pragma once
#include "Product.h"

class Monitor : public Product
{
public:
	Monitor(void);
	Monitor(Product* p){P = p;};
	~Monitor(void);

	int getPrice() {return 30 + P->getPrice(); } ;
	string getDescription() {return P->getDescription() + "\n�����";};

protected:
	Product* P;
};

