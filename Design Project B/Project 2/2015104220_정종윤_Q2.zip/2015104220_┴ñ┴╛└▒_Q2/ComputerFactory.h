#pragma once
#include "Product.h"
#include "BasePC.h"
#include "Monitor.h"
#include "Keyboard.h"
#include "Mouse.h"
#include "VGACard.h"

class ComputerFactory
{
public:
	ComputerFactory(void);
	~ComputerFactory(void);

	Product* makeProduct(int ID)
	{
		Product* NewProduct = new BasePC();
		switch(ID)
		{
		case 1:
			NewProduct = new Monitor(NewProduct);
			NewProduct = new Keyboard(NewProduct);
			NewProduct = new Mouse(NewProduct);
			break;
		case 2:
			NewProduct = new Monitor(NewProduct);
			NewProduct = new Keyboard(NewProduct);
			NewProduct = new Mouse(NewProduct);
			NewProduct = new VGACard(NewProduct);
			break;
		case 3:
			return NewProduct;
			break;

		default:
			return NewProduct;
		}

		return NewProduct;
	}
};

