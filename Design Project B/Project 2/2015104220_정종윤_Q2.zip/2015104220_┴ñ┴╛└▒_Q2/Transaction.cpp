#include "Transaction.h"


Transaction::Transaction(void)
{
}


Transaction::~Transaction(void)
{
}
