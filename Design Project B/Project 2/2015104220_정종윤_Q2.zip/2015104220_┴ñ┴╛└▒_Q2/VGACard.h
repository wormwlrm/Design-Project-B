#pragma once
#include "Product.h"

class VGACard : public Product
{
public:
	VGACard(void);
	VGACard(Product* p){P = p;};
	~VGACard(void);

	int getPrice() {return P->getPrice() + 70;}; 
	string getDescription() {return P->getDescription() + "\nVGAī��"; } ;

protected:
	Product* P;
};

