#include "Product.h"


Product::Product(void)
{
}


Product::~Product(void)
{
}
