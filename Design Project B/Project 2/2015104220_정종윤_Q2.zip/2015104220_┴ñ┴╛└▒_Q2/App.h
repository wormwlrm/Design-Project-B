#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "Product.h"
#include "ComputerFactory.h"
#include "Transaction.h"
using namespace std;

class App
{
public:
	App(void);
	~App(void);
	void run();

private:
	vector<Transaction> orderedList;
	ComputerFactory CF;
};

