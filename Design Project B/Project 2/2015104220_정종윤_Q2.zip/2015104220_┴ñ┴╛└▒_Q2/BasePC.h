#pragma once
#include "Product.h"

class BasePC : public Product
{
public:
	BasePC(void);
	~BasePC(void);

	int getPrice() {return 40;};
	string getDescription() {return "��ü";};
};

