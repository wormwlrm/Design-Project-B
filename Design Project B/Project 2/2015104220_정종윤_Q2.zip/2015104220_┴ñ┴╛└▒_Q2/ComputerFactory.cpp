#include "ComputerFactory.h"


ComputerFactory::ComputerFactory(void)
{
}


ComputerFactory::~ComputerFactory(void)
{
}
