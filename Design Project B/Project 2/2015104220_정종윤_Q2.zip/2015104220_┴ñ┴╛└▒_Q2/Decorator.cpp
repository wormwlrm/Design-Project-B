#include "Decorator.h"


Decorator::Decorator(void)
{
}


Decorator::~Decorator(void)
{
}

#include "Keyboard.h"

Keyboard::Keyboard(void)
{
}


Keyboard::~Keyboard(void)
{
}


#include "Monitor.h"
Monitor::Monitor(void)
{
}


Monitor::~Monitor(void)
{
}

#include "Mouse.h"
Mouse::Mouse(void)
{
}


Mouse::~Mouse(void)
{
}

#include "VGACard.h"
VGACard::VGACard(void)
{
}


VGACard::~VGACard(void)
{
}
