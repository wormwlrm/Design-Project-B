#pragma once
#include "Product.h"


class Transaction
{
public:
	Transaction(void);
	void setTransaction(Product* P) {orderedProduct = P; } ;
	~Transaction(void);
	void printTransaction()
	{
		cout << "*************************************************" << endl;
		cout << orderedProduct->getDescription() << endl;
		cout << orderedProduct->getPrice() << "����" << endl;		
	}
private:
	Product* orderedProduct;
};

