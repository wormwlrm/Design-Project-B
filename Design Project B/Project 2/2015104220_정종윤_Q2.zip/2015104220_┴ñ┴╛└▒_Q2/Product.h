#pragma once
#include <string>
#include <iostream>
using namespace std;

class Product
{
public:
	Product(void);
	~Product(void);

	virtual int getPrice() = 0;
	virtual string getDescription() = 0;

private:
	int Price;
	string Description;
};

