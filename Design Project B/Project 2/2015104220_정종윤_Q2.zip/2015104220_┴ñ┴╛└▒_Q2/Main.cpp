#include "App.h"

int main()
{
	App A;
	A.run();
	return 0;
}