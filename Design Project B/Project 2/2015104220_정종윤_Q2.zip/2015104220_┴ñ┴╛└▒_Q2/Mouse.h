#pragma once
#include "Product.h"

class Mouse : public Product
{
public:
	Mouse(void);
	Mouse(Product* p){P = p;};

	~Mouse(void);

	int getPrice() {return P->getPrice() + 3;};
	string getDescription() {return P->getDescription() + "\n���콺";};

protected:
	Product* P;
};

