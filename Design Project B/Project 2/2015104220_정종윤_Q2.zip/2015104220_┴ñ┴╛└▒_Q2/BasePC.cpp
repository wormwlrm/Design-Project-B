#include "BasePC.h"


BasePC::BasePC(void)
{
}


BasePC::~BasePC(void)
{
}
