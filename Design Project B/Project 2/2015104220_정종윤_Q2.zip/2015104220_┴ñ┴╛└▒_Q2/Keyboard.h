#pragma once
#include "Product.h"

class Keyboard : public Product
{
public:
	Keyboard(void);
	Keyboard(Product* p){P = p;};
	~Keyboard(void);

	int getPrice() {return 5 + P->getPrice();};
	string getDescription() {return P->getDescription() + "\nŰ����";};

protected:
	Product* P;
};

