#include "DiscountDrinkInStore.h"

DiscountDrinkInStore::DiscountDrinkInStore()
{

}

DiscountDrinkInStore::~DiscountDrinkInStore()
{

}

int DiscountDrinkInStore::discount(int price)
{
	return price;
}