#include "DiscountCoupon.h"

DiscountCoupon::DiscountCoupon()
{

}

DiscountCoupon::~DiscountCoupon()
{

}

int DiscountCoupon::discount(int price)
{
	return 0;
}