#include "TurnBehavior.h"	

TurnBehavior::TurnBehavior()
{

}

TurnBehavior::~TurnBehavior()
{

}

