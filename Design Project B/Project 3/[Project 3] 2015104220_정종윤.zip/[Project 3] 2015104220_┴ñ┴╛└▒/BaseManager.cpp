#include "BaseManager.h"

BaseManager::BaseManager()
{
	
}

BaseManager::~BaseManager()
{

}

void BaseManager::setFileName(string _name)
{
	fileName = _name;
}