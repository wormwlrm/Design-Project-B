#include "App.h"

int main()
{
	App Application;
	Application.run();

	return 0;
}